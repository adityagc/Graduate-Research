#Str() tells you type of object
#R indexes at 1
#each column needs to have same type in data.frame()
#$a gets 
# install.packages(c("tidyverse", "lubridate", "ggmap"))
# %>% passes one object to another.
# put your code in parathesis and execute entire block together. like ipython cell.
#ggmap

library(tidyverse)
a <- data.frame(c(1,2))
