"""_version.py: describes the package version."""

__version__ = "0.8.1"
